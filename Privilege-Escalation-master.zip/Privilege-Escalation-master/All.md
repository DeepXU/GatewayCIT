# Lab Designed for all types of Privilege Escalation (Vulnhub)

This is a List of CTF Challenges in which the complete lab is designed for Privilege Escalation. Clicking on the Lab Name, will redirect you to the writeup of that particular lab on [hackingarticles](https://www.hackingarticles.in). We have performed and compiled this list on our experience. Please share this with your connections and direct queries and feedback to [Pavandeep Singh](https://www.linkedin.com/in/pavan2318).

[1.1]: http://i.imgur.com/tXSoThF.png
[1]: http://www.twitter.com/rajchandel
# Follow us on [![alt text][1.1]][1]

| No | Machine Name                                                                                            |
|----|---------------------------------------------------------------------------------------------------------|
|1.  |[Lin.Security](https://www.hackingarticles.in/hack-the-lin-security-vm-boot-to-root/)|
|2.  |[Escalate_Linux](https://www.hackingarticles.in/escalate_linux-vulnhub-walkthrough-part-1/)|
|3.  |[Jigsaw:1](https://www.hackingarticles.in/jigsaw1-vulnhub-walkthrough/)|
