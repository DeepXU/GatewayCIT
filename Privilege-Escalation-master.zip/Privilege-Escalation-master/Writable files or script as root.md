## Writable files or script as root
This is a List of CTF Challenges in which privilege Escalation would be done by some writable file or script that can be executed as root. Clicking on the Lab Name, will redirect you to the writeup of that particular lab on [hackingarticles](https://www.hackingarticles.in). We have performed and compiled this list on our experience. Please share this with your connections and direct queries and feedback to [Pavandeep Singh](https://www.linkedin.com/in/pavan2318).

[1.1]: http://i.imgur.com/tXSoThF.png
[1]: http://www.twitter.com/rajchandel
# Follow us on [![alt text][1.1]][1]

| No | Machine Name                                                                                            |
|----|---------------------------------------------------------------------------------------------------------|
|1.	 |[Skydog](https://www.hackingarticles.in/hack-skydog-vm-ctf-challenge/)|
|2.	 |[Breach 1.0](https://www.hackingarticles.in/hack-breach-1-0-vm-ctf-challenges/)|
|3.	 |[Bot Challenge: Dexter](https://www.hackingarticles.in/hack-bot-challenge-dexter-boot2root-challenge/)|
|4.	 |[Fowsniff : 1](https://www.hackingarticles.in/fowsniff-1-vulnhub-walkthrough/)|
|5.	 |[Mercy](https://www.hackingarticles.in/mercy-vulnhub-walkthrough/)|
|6.	 |[Casino Royale](https://www.hackingarticles.in/casino-royale-1-vulnhub-walkthrough/)|
|7.	 |[SP eric](https://www.hackingarticles.in/sp-eric-vulnhub-lab-walkthrough/)|
|8.	 |[PumpkinGarden](https://www.hackingarticles.in/pumpkingarden-vulnhub-walkthrough/)|
|9.	 |[Tr0ll: 3](https://www.hackingarticles.in/tr0ll-3-vulnhub-walkthrough/)|
|10. |[Nezuko:1](https://www.hackingarticles.in/nezuko-1-vulnhub-walkthrough/)|
|11. |[Symfonos:3](https://www.hackingarticles.in/symfonos3-vulnhub-walkthrough/)|
|12. |[Tr0ll 1](https://www.hackingarticles.in/hack-the-troll-1-vm-boot-to-root/)|
|13. |[DC:7](https://www.hackingarticles.in/dc7-vulnhub-walkthrough/)|
