# Privilege Escalation by Capabilities (Vulnhub)

This is a List of CTF Challenges in which privilege Escalation would be done by Capabilities. Clicking on the Lab Name, will redirect you to the writeup of that particular lab on [hackingarticles](https://www.hackingarticles.in). We have performed and compiled this list on our experience. Please share this with your connections and direct queries and feedback to [Pavandeep Singh](https://www.linkedin.com/in/pavan2318).

[1.1]: http://i.imgur.com/tXSoThF.png
[1]: http://www.twitter.com/rajchandel
# Follow us on [![alt text][1.1]][1]

| No | Machine Name                                                                                            |
|----|---------------------------------------------------------------------------------------------------------|
|1.	 |[Kuya : 1](https://www.hackingarticles.in/vulnhub-kuya-1-walkthrough/)|
|2.	 |[DomDom: 1](https://www.hackingarticles.in/domdom-1-vulnhub-walkthrough/)|
|3.  |[HA: Naruto](https://www.hackingarticles.in/ha-naruto-vulnhub-walkthrough/)
